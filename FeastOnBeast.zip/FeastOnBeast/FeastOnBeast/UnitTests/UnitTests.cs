﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Threading.Tasks;
using FeastOnBeast.Data.Repository;
using FeastOnBeast.Migrations;
using FeastOnBeast.Controllers;
using FeastOnBeast.Models;
using Moq;

namespace FeastOnBeast.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Can_GetPost()
        {
            // Arrange   
            //TODO: Fix to ensure unit test works
        
            Mock<IRepository> mock = new Mock<IRepository>();
            mock.Setup(m => m.Posts).Returns(new Post[]
            {
                new Post {PostId = 1},
                new Post {PostId = 2},
                new Post {PostId = 3},
                new Post {PostId = 4},
                new Post {PostId = 5}
            });

            Post post = new Post
            {
                PostId = 3
            };

            // Assert            
            Assert.IsTrue(post.PostId == 3);
        }
    }
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void AuthorizationCheck()
        {
            // Arrange            
            Mock<IRepository> mock = new Mock<IRepository>();
            //TODO: Test to ensure authorization works

            // Assert            
            
        }
    }
    [TestClass]
    public class UnitTest3
    {
        [TestMethod]
        public void Can_PostPicture()
        {
            // Arrange            
            Mock<IRepository> mock = new Mock<IRepository>();
            //TODO: Test that post picture works for admin only          

            // Assert            
            
        }
    }
    [TestClass]
    public class UnitTest4
    {
        [TestMethod]
        public void Can_PostRecipe()
        {
            // Arrange            
            Mock<IRepository> mock = new Mock<IRepository>();
            //TODO: Test that post recipe works for admin only         

            // Assert            

        }
    }
}
