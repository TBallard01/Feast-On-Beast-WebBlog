﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FeastOnBeast.Models;

namespace FeastOnBeast.Data.Repository
{
    public class Repository : IRepository
    {
        private AppDbContext _ctx;

        

        public Repository(AppDbContext ctx)
        {
            _ctx = ctx;
        }
        public IEnumerable<Post> Posts { get { return _ctx.Posts; } }
        public IEnumerable<Recipe> Recipes { get { return _ctx.Recipes; } }
        public void AddPost(Post post)
        {
            _ctx.Posts.Add(post);         
        }

        public Post GetPost(int id)
        {
            return _ctx.Posts.FirstOrDefault(p => p.PostId == id);
        }

        public void RemovePost(int id)
        {
            _ctx.Remove(GetPost(id));
        }

        public void UpdatePost(Post post)
        {
            _ctx.Posts.Update(post);
        }

        public async Task<bool> SaveChangesAsync()
        {
            if(await _ctx.SaveChangesAsync() >0)
            {
                return true;
            }
            return false;
        }
    }
}
