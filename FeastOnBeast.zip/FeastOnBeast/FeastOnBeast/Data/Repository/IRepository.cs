﻿using FeastOnBeast.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FeastOnBeast.Data.Repository
{
    public interface IRepository
    {
        IEnumerable<Post> Posts { get; }

        Post GetPost(int id);
        List <Post> GetAllPosts();
        void AddPost(Post post);
        void RemovePost(int id);
        void UpdatePost(Post post);

        Task<bool> SaveChangesAsync();
    }
}
