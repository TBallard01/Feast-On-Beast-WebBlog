﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeastOnBeast.Models;

namespace FeastOnBeast.Data.Repository
{
    public interface IRecipeRepository
    {
        IEnumerable<Recipe> Recipes { get; }

        Recipe GetPost(int id);
        List<Recipe> GetAllPosts();
        void AddPost(Recipe post);
        void RemovePost(int id);
        void UpdatePost(Recipe post);

        Task<bool> SaveChangesAsync();
    }
}
