﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeastOnBeast.Models;

namespace FeastOnBeast.Data.Repository
{
    public class RecipeRepository : IRecipeRepository
    {
        private AppDbContext _ctx;

        public IEnumerable<Recipe> Recipes => throw new NotImplementedException();

        public RecipeRepository(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public void AddPost(Recipe recipe)
        {
            _ctx.Recipes.Add(recipe);
        }

        public List<Recipe> GetAllPosts()
        {
            return _ctx.Recipes.ToList();
        }

        public Recipe GetPost(int id)
        {
            return _ctx.Recipes.FirstOrDefault(p => p.RecipeId == id);
        }

        public void RemovePost(int id)
        {
            _ctx.Remove(GetPost(id));
        }

        public void UpdatePost(Recipe recipe)
        {
            _ctx.Recipes.Update(recipe);
        }

        public async Task<bool> SaveChangesAsync()
        {
            if (await _ctx.SaveChangesAsync() > 0)
            {
                return true;
            }
            return false;
        }
    }
}
