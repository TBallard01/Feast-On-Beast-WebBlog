﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FeastOnBeast.Migrations
{
    public partial class TestingMigrations : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
