﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FeastOnBeast.Models;
using FeastOnBeast.Data;
using FeastOnBeast.Data.Repository;

namespace FeastOnBeast.Controllers
{
    public class HomeController : Controller
    {
        private IRepository _repo;

        public HomeController(IRepository repo)
        {
            _repo = repo;
        }

        public IActionResult Index()
        {
            var posts = _repo.GetAllPosts();
            return View(posts);
        }

        public IActionResult Gallery()
        {
            return View();
        }

        public IActionResult Recipes()
        {
            return View();
        }

        public IActionResult Gear()
        {
            return View();
        }

        public IActionResult Blog(int id)
        {
            var post = _repo.GetPost(id);

            return View(post);
        }
    }
}
