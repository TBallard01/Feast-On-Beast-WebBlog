﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using FeastOnBeast.Data.Repository;
using FeastOnBeast.Models;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using FeastOnBeast.ViewModels;
using FeastOnBeast.Data.FileManager;

namespace FeastOnBeast.Controllers
{
        [Authorize(Roles = "Admin")]
        public class RecipeController : Controller
        {
            private IRepository _recipeRepo;
            private IFileManager _fileManager;

            public RecipeController(IRepository repo, IFileManager fileManager)
            {
                _recipeRepo = repo;
                _fileManager = fileManager;
            }

        [HttpGet]
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return View(new PostViewModel { });
            }
            else
            {
                var post = _recipeRepo.GetPost((int)id);
                return View(new PostViewModel
                {
                    Id = post.PostId,
                    Title = post.Title,
                    Body = post.Body
                });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Edit(PostViewModel vm)
        {
            var post = new Post
            {
                PostId = vm.Id,
                Title = vm.Title,
                Body = vm.Body,
                Image = await _fileManager.SaveImage(vm.Image)
            };

            if (post.PostId > 0)
            {
                _recipeRepo.UpdatePost(post);
            }
            else
            {
                _recipeRepo.AddPost(post);
            }

            if (await _recipeRepo.SaveChangesAsync())
            {
                return RedirectToAction("Index");
            }
            else
            {
                return View(post);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Remove(int id)
        {
            _recipeRepo.RemovePost(id);
            await _recipeRepo.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
            public IActionResult Error()
            {
                return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
        }
}