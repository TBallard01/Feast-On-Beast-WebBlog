﻿using FeastOnBeast.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FeastOnBeast.ViewModels
{
    public class PanelContentViewModel
    {
        public IEnumerable<Post> Posts { get; set; }
        public IEnumerable<Recipe> Recipes { get; set; }
    }
}
